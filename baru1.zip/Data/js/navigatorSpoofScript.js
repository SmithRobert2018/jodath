Object.defineProperty(navigator, "plugins", {
	get: () => {
		return {
			length: 0,
			item: () => null,
			namedItem: () => null,
			refresh: () => {},
		};
	},
});

Object.defineProperty(navigator, "userAgent", {
	get: () =>
		"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
});

Object.defineProperty(navigator, "userAgentData", {
	get: () => "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
});

Object.defineProperty(navigator, "languages", {
	get: () => ["th-TH", "th"],
});

Object.defineProperty(navigator, "platform", {
	get: () => "MacIntel",
});

Object.defineProperty(navigator, "deviceMemory", {
	get: () => 8,
});

Object.defineProperty(navigator, "hardwareConcurrency", {
	get: () => 8,
});

Object.defineProperty(screen, "width", {
	get: () => 2560,
});

Object.defineProperty(screen, "height", {
	get: () => 1440,
});

Object.defineProperty(screen, "availWidth", {
	get: () => 2560,
});

Object.defineProperty(screen, "availHeight", {
	get: () => 1440,
});

Object.defineProperty(Date.prototype, "getTimezoneOffset", {
	get: () => () => -420,
});

Object.defineProperty(Intl.DateTimeFormat.prototype, "resolvedOptions", {
    get: () => () => {
        return {
            locale: "th-TH",
            calendar: "gregory",
            numberingSystem: "latn",
            timeZone: "Asia/Bangkok",
            year: "numeric",
            month: "numeric",
            day: "numeric"
        };
    },
});
